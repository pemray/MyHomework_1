﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace Common
{
    public interface IDBHelper
    {
        /// <summary>
        /// 查询单个-通过主键id查询
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="id"></param>
        /// <returns></returns>
        T QueryOneById<T>(int id) where T : BaseModel;

        /// <summary>
        /// 查询所有
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        List<T> QueryAll<T>();

        /// <summary>
        /// 新增
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="t"></param>
        /// <returns></returns>
        bool AddOne<T>(T t);

        /// <summary>
        /// 更新-通过主键id更新数据
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="id"></param>
        /// <returns></returns>
        bool UpdateOneById<T>(T t,int id) where T : BaseModel;

        /// <summary>
        /// 删除-通过主键id删除
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="id"></param>
        /// <returns></returns>
        bool DeleteOneById<T>(int id) where T : BaseModel;

    }
}
