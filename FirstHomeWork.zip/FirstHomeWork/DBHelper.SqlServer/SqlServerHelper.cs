﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Common;
using System.Data.SqlClient;

namespace DBHelper.SqlServer
{
    public class SqlServerHelper : IDBHelper
    {
        public string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

        #region IDBHelper接口方法
        public T QueryOneById<T>(int id) where T : Model.BaseModel
        {
            Type type = typeof(T);
            //拼接列
            string column = string.Join(",", type.GetProperties().Select(p => string.Format("[{0}]", p.Name.ToUpper())));
            string sql = string.Format("SELECT {0} FROM [{1}] WHERE ID={2}", column, type.Name.ToUpper(), id);
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                //创建实例
                object obj = Activator.CreateInstance(type);
                SqlCommand command = new SqlCommand(sql, conn);
                conn.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    foreach (var item in type.GetProperties())
                    {
                        item.SetValue(obj, reader[item.Name]);
                    }
                }
                return obj as T;
            }
        }

        public List<T> QueryAll<T>()
        {
            Type type = typeof(T);
            //拼接列
            string column = string.Join(",", type.GetProperties().Select(p => string.Format("[{0}]", p.Name.ToUpper())));
            string sql = string.Format("SELECT {0} FROM [{1}] ", column, type.Name.ToUpper());
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                List<T> lt = new List<T>();
                //创建实例
                object obj = new object();
                SqlCommand command = new SqlCommand(sql, conn);
                conn.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    obj = Activator.CreateInstance(type);
                    foreach (var item in type.GetProperties())
                    {
                        item.SetValue(obj, reader[item.Name]);
                    }
                    lt.Add((T)obj);
                }
                return lt;
            }
        }

        public bool AddOne<T>(T t)
        {
            Type type = typeof(T);
            //拼接列(排除主键列-ID)
            string column = string.Join(",", type.GetProperties().Where(p => p.Name.ToUpper() != "ID").Select(p => string.Format("[{0}]", p.Name.ToUpper())));
            //拼接值(排除主键列的值)
            string values = string.Join(",", type.GetProperties().Where(p => p.Name.ToUpper() != "ID").Select(p => string.Format("'{0}'", p.GetValue(t))));
            string sql = string.Format("INSERT INTO [{0}]({1}) VALUES({2})", type.Name.ToUpper(), column, values);
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                SqlCommand command = new SqlCommand(sql, conn);
                conn.Open();
                return command.ExecuteNonQuery() > 0;
            }
        }

        public bool UpdateOneById<T>(T t, int id) where T : Model.BaseModel
        {
            Type type = typeof(T);
            //拼接值(排除主键列的值)
            string values = string.Join(",", type.GetProperties().Where(p => p.Name.ToUpper() != "ID").Select(p => string.Format("[{0}]='{1}'", p.Name.ToUpper(), p.GetValue(t))));
            string sql = string.Format("UPDATE [{0}] SET {1} WHERE ID={2}", type.Name.ToUpper(), values, id);
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                SqlCommand command = new SqlCommand(sql, conn);
                conn.Open();
                return command.ExecuteNonQuery() > 0;
            }
        }

        public bool DeleteOneById<T>(int id) where T : Model.BaseModel
        {
            Type type = typeof(T);
            string sql = string.Format("DELETE [{0}] WHERE ID={1}", type.Name.ToUpper(), id);
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                SqlCommand command = new SqlCommand(sql, conn);
                conn.Open();
                return command.ExecuteNonQuery() > 0;
            }
        }
        #endregion
    }
}
