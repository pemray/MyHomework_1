﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Common;
using System.Reflection;

namespace Factory
{
    public static class DBSimpleFactory
    {
        private static string currentDB = ConfigurationManager.AppSettings["currentDB"];

        public static IDBHelper CreateInstance()
        {
            string[] arr = currentDB.Split(',');
            Assembly assembly = Assembly.Load(arr[0]);
            Type type = assembly.GetType(arr[1]);
            object obj = Activator.CreateInstance(type);
            return obj as IDBHelper;
        }
    }
}
