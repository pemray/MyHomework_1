﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using Factory;
using Model;
using Common;
using System.Reflection;

namespace FirstHomeWork
{
    public class Program
    {
        static IDBHelper iDBHelper = Factory.DBSimpleFactory.CreateInstance();
        static User loginUser = null;
        static void Main(string[] args)
        {
            Console.WriteLine("*******欢迎进入*********");
            {
                string input = "";
                while (true)
                {
                    try
                    {
                        if (loginUser == null)
                        {
                            loginUser = iDBHelper.QueryOneById<User>(1);
                            ConsoleTips(string.Format("欢迎你,{0}", loginUser.Name));
                        }
                        ConsoleMenu("1.公司 2.员工");
                        ConsoleTips("请选择");
                        input = Console.ReadLine();
                        if (input == "1")
                        {
                            CompanyInit();
                        }
                        else if (input == "2")
                        {
                            UserInit();
                        }
                        else
                        {
                            ConsoleTips("请输入正确选择");
                        }
                    }
                    catch (Exception ex)
                    {
                        ConsoleError("出现错误:" + ex.ToString());
                        ConsoleTips("任意键退出");
                        Console.ReadLine();
                        break;
                    }
                }
            }
        }

        #region 公司
        public static void CompanyInit()
        {
            ConsoleMenu("1.新增 2.查询公司 3.删除公司 4.查询所有公司 5.修改公司");
            ConsoleTips("请选择");
            CompanyOperation(Console.ReadLine());
        }
        public static void CompanyOperation(string type)
        {
            switch (type)
            {
                case "1":
                    //新增,这里只需要输入公司名称,其他默认(没有判断数据重复问题)
                    ConsoleTips("请输入公司名称");
                    string name = Console.ReadLine();
                    if (name.Trim() == "")
                    {
                        ConsoleError("输入错误");
                        CompanyOperation("1");
                        break;
                    }
                    Company c = new Company()
                    {
                        Id = 0,//主键自增长,在SQL中已处理
                        Name = name,
                        CreateTime = DateTime.Now,
                        CreatorId = loginUser.Id,//默认admin(loginUser.Id)
                        LastModifierId = loginUser.Id,//默认admin
                        LastModifyTime = DateTime.Now
                    };
                    if (iDBHelper.AddOne<Company>(c))
                    {
                        ConsoleResult("新增成功\n");
                    }
                    break;
                case "2":
                    ConsoleTips("请输入公司ID");
                    int id = int.Parse(Console.ReadLine());//这里如果不是数字就会异常
                    Company company = iDBHelper.QueryOneById<Company>(id);
                    Type typeCompany = typeof(Company);
                    ConsoleTips("公司信息如下:");
                    ConsoleResult(string.Join("\n", typeCompany.GetProperties().Select(p => string.Format("{0}={1}", p.Name.ToLower(), p.GetValue(company)))));
                    break;
                case "3":
                    Console.WriteLine("请输入公司ID");
                    int delId = int.Parse(Console.ReadLine());//这里如果不是数字就会异常
                    if (iDBHelper.DeleteOneById<Company>(delId))
                    {
                        ConsoleResult("删除成功\n");
                    }
                    else
                    {
                        ConsoleResult("删除失败\n");
                    }
                    break;
                case "4":
                    List<Company> listCompany = iDBHelper.QueryAll<Company>();
                    //分组
                    var gb = listCompany.GroupBy(p => new { p.Name }).ToList();
                    Type typeCompanyList = typeof(Company);
                    ConsoleTips("公司信息如下(公司名称分组):");
                    int i = 0;
                    ConsoleTips(string.Join(" ", typeCompanyList.GetProperties().Select(p => p.Name.ToLower())));
                    foreach (var item in gb)
                    {
                        foreach (var ic in item)
                        {
                            i++;
                            ConsoleResult(string.Join(" ", typeCompanyList.GetProperties().Select(p => string.Format("{0}", p.GetValue(ic)))));
                        }
                    }
                    ConsoleTips(string.Format("共{0}个", i));
                    break;
                case "5":
                    ConsoleTips("请输入公司ID");
                    int companyId = int.Parse(Console.ReadLine());
                    Company companyOld = iDBHelper.QueryOneById<Company>(companyId);
                    if (companyOld == null)
                    {
                        ConsoleTips("未找到该公司");
                        CompanyOperation("5");
                    }
                    else
                    {
                        Company updateC = companyOld;
                        ConsoleTips("请输入要改的公司名称");
                        string updateName = Console.ReadLine();
                        updateC.Name = updateName;
                        if (iDBHelper.UpdateOneById<Company>(updateC, companyId))
                        {
                            ConsoleResult("修改成功\n");
                        }
                        else
                        {
                            ConsoleResult("修改失败\n");
                        }
                    }
                    break;
                default:
                    ConsoleTips("请输入正确选择");
                    CompanyInit();
                    break;
            }
        }
        #endregion

        #region 用户
        public static void UserInit()
        {
            ConsoleMenu("1.新增 2.查询用户 3.删除用户 4.查询所有用户 5.修改用户");
            ConsoleTips("请选择");
            UserOperation(Console.ReadLine());
        }
        public static void UserOperation(string type)
        {
            switch (type)
            {
                case "1":
                    //新增,这里只需要输入用户名称,其他默认(没有判断数据重复问题)
                    ConsoleTips("请输入用户名称");
                    string name = Console.ReadLine();
                    if (name.Trim() == "")
                    {
                        ConsoleError("输入错误");
                        UserOperation("1");
                        break;
                    }
                    ConsoleTips("请输入用户账号(禁止输入admin,不区分大小写)");
                    string account = Console.ReadLine();
                    if (name.Trim() == "")
                    {
                        ConsoleError("输入错误");
                        UserOperation("1");
                        break;
                    }
                    else if (account.ToLower() == "admin")
                    {
                        ConsoleError("输入错误,禁止输入admin");
                        UserOperation("1");
                        break;
                    }
                    else
                    {
                        User user = new User()
                        {
                            Id = 0,//主键自增长,在SQL中已处理
                            Name = name,
                            Account = account,
                            Password = "888888",
                            Email = "123@123.com",
                            Mobile = "13912345678",
                            CompanyId = 1,//此处默认
                            CompanyName = "百捷",//此处默认
                            State = 1,
                            UserType = 1,
                            LastLoginTime = DateTime.Now,
                            CreateTime = DateTime.Now,
                            CreatorId = loginUser.Id,
                            LastModifierId = loginUser.Id,
                            LastModifyTime = DateTime.Now
                        };
                        if (iDBHelper.AddOne<User>(user))
                        {
                            ConsoleResult("新增成功\n");
                        }
                    }
                    break;
                case "2":
                    ConsoleTips("请输入用户ID");
                    int id = int.Parse(Console.ReadLine());//这里如果不是数字就会异常
                    User _user = iDBHelper.QueryOneById<User>(id);
                    ConsoleTips("用户信息如下:");
                    ConsoleResult(string.Join("\n", typeof(User).GetProperties().Select(p => string.Format("{0}={1}", p.Name.ToLower(), p.GetValue(_user)))));
                    break;
                case "3":
                    Console.WriteLine("请输入用户ID");
                    int delId = int.Parse(Console.ReadLine());//这里如果不是数字就会异常
                    if (iDBHelper.DeleteOneById<User>(delId))
                    {
                        ConsoleResult("删除成功\n");
                    }
                    else
                    {
                        ConsoleResult("删除失败\n");
                    }
                    break;
                case "4":
                    List<User> listUser = iDBHelper.QueryAll<User>();
                    int listCount = listUser.Count();
                    
                    #region Skip/SkipWhile
                    //和Take相反.获取排除前几条之外的数据.类似Substring(1)方法
                    List<User> skip = listUser.Skip(1).ToList();
                    //和TakeWhile相反,只要满足就返回剩下的所有元素
                    List<User> skipWhile = listUser.SkipWhile(p => p.Id > 0).ToList();
                    #endregion

                    #region 平均值-Average
                    double avg = listUser.Average(p => p.UserType);
                    ConsoleResult("用户的UserType的平均值:" + avg);
                    #endregion

                    #region 排序
                    //listUser = listUser.OrderBy(p=>p.Id).ToList();//升序
                    //listUser = listUser.OrderByDescending(p => p.Id).ToList();//倒序 
                    #endregion

                    #region Take/TakeWhile
                    //选择前几条,类似SqlServer的top
                    //listUser = listUser.Take(30).ToList();
                    //如果条件不满足就直接返回结果集(不包含当前结果)并且不会处理后面的数据.类似while的break效果
                    //listUser = listUser.TakeWhile(p => p.Id > 0).ToList();
                    #endregion

                    #region Max/Min
                    //获取用户类型UserType最大的
                    //listUser.Select(p => p.UserType = listUser.Max(u => u.UserType)).ToList();//返回UserType最大用户对象集合
                    ConsoleResult("UserType最大的:" + listUser.Max(p => p.UserType));
                    //获取用户类型UserType最小的
                    //listUser.Select(p => p.UserType = listUser.Min(u => u.UserType)).ToList();//返回UserType最小用户对象集合
                    ConsoleResult("UserType最小的:" + listUser.Min(p => p.UserType));
                    #endregion

                    #region Distinct
                    //非默认方法,该类必须实现IEqualityComparer<T>接口,这里通过名称来排除重复
                    List<User> userDistinct = listUser.OrderByDescending(p => p.Id).Distinct(new User()).ToList();
                    //listUser = userDistinct; //查看去重结果
                    ConsoleResult(string.Format("总共{0}个,去重筛选后{1}个", listCount, userDistinct.Count));
                    #endregion

                    #region Join
                    List<Company> lCompany = iDBHelper.QueryAll<Company>();
                    lCompany = lCompany.Distinct(new Company()).ToList();//去重
                    //改变公司名称
                    for (int j = 0; j < lCompany.Count; j++)
                    {
                        lCompany[j].Name = lCompany[j].Name + j;
                    }
                    //使用Join,让用户和改变的公司匹配(输出公司新名称)
                    #region Join方法
                    var l = listUser.Join(lCompany, u => u.CompanyId, c => c.Id, (u, c) => new User
                                {
                                    Id = u.Id,
                                    Name = u.Name,
                                    Account = u.Account,
                                    Password = u.Password,
                                    Email = u.Email,
                                    Mobile = u.Mobile,
                                    CompanyId = u.CompanyId,
                                    CompanyName = "旧公司名称:" + u.CompanyName + ",新公司名称:" + c.Name,
                                    State = u.State,
                                    UserType = u.UserType,
                                    LastLoginTime = u.LastLoginTime,
                                    CreateTime = u.CreateTime,
                                    CreatorId = u.CreatorId,
                                    LastModifierId = u.LastModifierId,
                                    LastModifyTime = u.LastModifyTime
                                });
                    //输出
                    ConsoleTips("用户信息如下(使用Join方法):");
                    foreach (var item in l)
                    {
                        ConsoleResult(string.Join("\n", typeof(User).GetProperties().Select(p => string.Format("{0}={1}", p.Name.ToLower(), p.GetValue(item)))));//p.GetValue(item)
                    }
                    #endregion

                    #region Join查询表达式
                    List<User> userJoin = (
                        //处理好数据为空的情况
                                   from c in lCompany
                                   join u in listUser on c.Id equals u.CompanyId into t
                                   //当d没有数据时返回一个user对象,并且设置id为0(表示该对象是非法数据),然后排除小于0的
                                   from d in t.DefaultIfEmpty(new User() { Id = 0 })
                                   where d.Id > 0
                                   let newCompanyName = "旧公司名称:" + (d == null ? "" : d.CompanyName) + ",新公司名称:" + (c == null ? "" : c.Name)
                                   select new User()
                                   {
                                       Id = d.Id,
                                       Name = d.Name,
                                       Account = d.Account,
                                       Password = d.Password,
                                       Email = d.Email,
                                       Mobile = d.Mobile,
                                       CompanyId = d.CompanyId,
                                       CompanyName = newCompanyName,
                                       State = d.State,
                                       UserType = d.UserType,
                                       LastLoginTime = d.LastLoginTime,
                                       CreateTime = d.CreateTime,
                                       CreatorId = d.CreatorId,
                                       LastModifierId = d.LastModifierId,
                                       LastModifyTime = d.LastModifyTime
                                   }
                                   ).ToList();
                    ConsoleTips("用户信息如下(使用Join查询表达式):");
                    foreach (var item in userJoin)
                    {
                        ConsoleResult(string.Join("\n", typeof(User).GetProperties().Select(p => string.Format("{0}={1}", p.Name.ToLower(), p.GetValue(item)))));
                    }
                    #endregion

                    #endregion

                    #region GroupBy
                    //分组
                    var gb = listUser.GroupBy(p => new { p.Name }).ToList();
                    Type typeUserList = typeof(User);
                    ConsoleTips("用户信息如下(用户名称分组GroupBy):");
                    int i = 0;
                    foreach (var item in gb)
                    {
                        foreach (var ic in item)
                        {
                            i++;
                            ConsoleResult(string.Join("\n", typeUserList.GetProperties().Select(p => string.Format("{0}={1}", p.Name.ToLower(), p.GetValue(ic)))));
                        }
                    }
                    ConsoleTips(string.Format("总共{0}个,筛选后{1}个", listCount, i));
                    #endregion

                    break;
                case "5":
                    ConsoleTips("请输入用户ID");
                    int userId = int.Parse(Console.ReadLine());
                    User userOld = iDBHelper.QueryOneById<User>(userId);
                    if (userOld == null)
                    {
                        ConsoleTips("未找到该用户");
                        UserOperation("5");
                    }
                    else
                    {
                        User updateU = userOld;
                        ConsoleTips("请输入要改的用户名称");
                        string updateName = Console.ReadLine();
                        updateU.Name = updateName;
                        if (iDBHelper.UpdateOneById<User>(updateU, userId))
                        {
                            ConsoleResult("修改成功\n");
                        }
                        else
                        {
                            ConsoleResult("修改失败\n");
                        }
                    }
                    break;
                default:
                    ConsoleTips("请输入正确选择");
                    UserInit();
                    break;
            }
        }
        #endregion

        #region 输出方式
        /// <summary>
        /// 打印错误(红色)
        /// </summary>
        /// <param name="msg"></param>
        public static void ConsoleError(string msg)
        {
            Console.ForegroundColor = ConsoleColor.Red;//红色字体
            Console.WriteLine(msg);
            Console.ForegroundColor = ConsoleColor.White;//重置为白色字体
        }

        /// <summary>
        /// 打印结果(绿色)
        /// </summary>
        /// <param name="msg"></param>
        public static void ConsoleResult(string msg)
        {
            Console.ForegroundColor = ConsoleColor.Green;//绿色字体
            Console.WriteLine(msg);
            Console.ForegroundColor = ConsoleColor.White;//重置为白色字体
        }

        /// <summary>
        /// 打印提示(黄色)
        /// </summary>
        /// <param name="msg"></param>
        public static void ConsoleTips(string msg)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;//黄色字体
            Console.WriteLine(msg);
            Console.ForegroundColor = ConsoleColor.White;//重置为白色字体
        }

        /// <summary>
        /// 打印菜单
        /// </summary>
        /// <param name="msg"></param>
        public static void ConsoleMenu(string msg)
        {
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine(msg);
            Console.ForegroundColor = ConsoleColor.White;//重置为白色字体
        }
        #endregion
    }
}
