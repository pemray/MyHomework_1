﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Company : BaseModel, IEqualityComparer<Company>
    {
        #region 字段
        /// <summary>
        /// 公司id
        /// </summary>
        public new int Id { get; set; }
        /// <summary>
        /// 公司名称
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 创建人id
        /// </summary>
        public int CreatorId { get; set; }
        /// <summary>
        /// 最后修改人id
        /// </summary>
        public int LastModifierId { get; set; }
        /// <summary>
        /// 最后修改时间
        /// </summary>
        public DateTime LastModifyTime { get; set; } 
        #endregion

        #region IEqualityComparer接口方法
        public bool Equals(Company x, Company y)
        {
            return x.Name == y.Name;
        }

        public int GetHashCode(Company obj)
        {
            return obj.ToString().GetHashCode();
        }
        #endregion
       
    }
}
