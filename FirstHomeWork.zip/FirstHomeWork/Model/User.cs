﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    /// <summary>
    /// 人员(员工)
    /// </summary>
    public class User : BaseModel, IEqualityComparer<User>
    {

        #region 字段
        /// <summary>
        /// 主键id(人员id)
        /// </summary>
        public new int Id { get; set; }
        /// <summary>
        /// 人员名称
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 账号
        /// </summary>
        public string Account { get; set; }
        /// <summary>
        /// 密码
        /// </summary>
        public string Password { get; set; }
        /// <summary>
        /// 邮箱
        /// </summary>
        public string Email { get; set; }
        /// <summary>
        /// 手机
        /// </summary>
        public string Mobile { get; set; }
        /// <summary>
        /// 公司id
        /// </summary>
        public int CompanyId { get; set; }
        /// <summary>
        /// 公司名称
        /// </summary>
        public string CompanyName { get; set; }
        /// <summary>
        /// 用户状态  0正常 1冻结 2删除
        /// </summary>
        public int State { get; set; }
        /// <summary>
        /// 用户类型  1普通用户 2管理员 4超级管理员
        /// </summary>
        public int UserType { get; set; }
        /// <summary>
        /// 最后登录时间
        /// </summary>
        public DateTime LastLoginTime { get; set; }
        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 创建人id
        /// </summary>
        public int CreatorId { get; set; }
        /// <summary>
        /// 最后修改人id
        /// </summary>
        public int LastModifierId { get; set; }
        /// <summary>
        /// 最后修改时间
        /// </summary>
        public DateTime LastModifyTime { get; set; }
        #endregion

        #region IEqualityComparer接口方法
        public bool Equals(User x, User y)
        {
            return x.Name == y.Name;
        }

        public int GetHashCode(User obj)
        {
            return obj.ToString().GetHashCode();
        }
        #endregion
    }
}